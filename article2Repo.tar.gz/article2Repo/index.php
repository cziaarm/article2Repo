<?php

require_once('Article2Repo.inc.php');

return new Article2Repo();

?>
